@include('layouts.header')
<div class="">
    @yield('main-section')
</div>
@include('layouts.footer')